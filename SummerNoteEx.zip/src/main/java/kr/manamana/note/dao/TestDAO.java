package kr.manamana.note.dao;

import java.util.HashMap;

public interface TestDAO {
	public String today();
	public int mul(HashMap<String, Integer> map);
	public int sum(HashMap<String, Integer> map);
	
}
