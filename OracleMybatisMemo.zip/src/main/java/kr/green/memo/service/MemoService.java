package kr.green.memo.service;

import org.apache.log4j.Logger;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;

import kr.green.memo.dao.MemoDAO;
import kr.green.memo.mybatis.MybatisApp;
import kr.green.memo.vo.MemoVO;
import kr.green.memo.vo.PagingVO;

public class MemoService {

	private static final Logger logger = Logger.getLogger(MemoService.class);

	private static MemoService instance = new MemoService();

	private MemoService() {
	}

	public static MemoService getInstance() {
		return instance;
	}
	// ==================================================================================

	// 1. 목록보기
	public PagingVO<MemoVO> selectList(int currentPage, int pageSize, int blockSize) {
		PagingVO<MemoVO> pagingVO = null; // 여기가 바뀐다.

		if (logger.isDebugEnabled()) {
			logger.debug("selectList(int, int, int) - start 인수 : "+ currentPage + ", " + pageSize + ", " + blockSize); //$NON-NLS-1$
		}

		SqlSession sqlSession = null;
		MemoDAO memoDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			memoDAO = MemoDAO.getInstance();
			//---------------------------------------------------------------
			// 여기가 바뀐다.
			// 페이징 계산을 위하여 개수를 구한다.
			int totalCount = memoDAO.selectCount(sqlSession);
			// 페이지 계산을 한다.
			pagingVO = new PagingVO<MemoVO>(totalCount, currentPage, pageSize, blockSize);
			// 글목록을 얻기 위하여 데이터를 준비한다.
			HashMap<String, Integer> map = new HashMap<String, Integer>();
			map.put("startNo", pagingVO.getStartNo());
			map.put("endNo", pagingVO.getEndNo());
			// DAO를 호출하여 1페이지 분량의 데이터를 얻어 객체에 넣어준다.
			pagingVO.setList(memoDAO.selectList(sqlSession, map));
			//---------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			logger.error("selectList(int, int, int) 에러 : " + e.getMessage()); //$NON-NLS-1$

			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}

		if (logger.isDebugEnabled()) {
			logger.debug("selectList(int, int, int) - end 리턴 : " + pagingVO); //$NON-NLS-1$
		}
		return pagingVO; // 여기가 바뀐다.
	}
	// 저장
	public int insert(MemoVO memoVO) {
		int count = 0;
		if (logger.isDebugEnabled()) {
			logger.debug("insert(MemoVO) - start 인수 : "+ memoVO); //$NON-NLS-1$
		}

		SqlSession sqlSession = null;
		MemoDAO memoDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			memoDAO = MemoDAO.getInstance();
			//---------------------------------------------------------------
			// 여기가 바뀐다.
			if(memoVO!=null) {
				if(memoVO.getName()!=null && memoVO.getName().trim().length()>0) {
					if(memoVO.getPassword()!=null && memoVO.getPassword().trim().length()>0) {
						if(memoVO.getContent()!=null && memoVO.getContent().trim().length()>0) {
							if(memoVO.getIp()!=null && memoVO.getIp().trim().length()>0) {
								count = memoDAO.insert(sqlSession, memoVO);
							}
						}
					}
				}
			}
			//---------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			logger.error("insert(MemoVO) 에러 : " + e.getMessage()); //$NON-NLS-1$
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		if (logger.isDebugEnabled()) {
			logger.debug("insert(MemoVO) - end 리턴 : " + count); //$NON-NLS-1$
		}		
		return count;
	}
	// 수정
	public int update(MemoVO memoVO) {
		int count = 0;
		if (logger.isDebugEnabled()) {
			logger.debug("update(MemoVO) - start 인수 : "+ memoVO); //$NON-NLS-1$
		}

		SqlSession sqlSession = null;
		MemoDAO memoDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			memoDAO = MemoDAO.getInstance();
			//---------------------------------------------------------------
			// 여기가 바뀐다.
			if(memoVO!=null) {
				if(memoVO.getName()!=null && memoVO.getName().trim().length()>0) {
					if(memoVO.getPassword()!=null && memoVO.getPassword().trim().length()>0) {
						MemoVO dbVO = memoDAO.selectByIdx(sqlSession, memoVO.getIdx());
						if(dbVO!=null && dbVO.getPassword().equals(memoVO.getPassword())) {
							if(memoVO.getContent()!=null && memoVO.getContent().trim().length()>0) {
								if(memoVO.getIp()!=null && memoVO.getIp().trim().length()>0) {
									count = memoDAO.update(sqlSession, memoVO);
								}
							}
						}
					}
				}
			}
			//---------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			logger.error("update(MemoVO) 에러 : " + e.getMessage()); //$NON-NLS-1$
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}

		if (logger.isDebugEnabled()) {
			logger.debug("update(MemoVO) - end 리턴 : " + count); //$NON-NLS-1$
		}				
		return count;
	}
	
	// 삭제
	public int delete(MemoVO memoVO) {
		int count = 0;
		if (logger.isDebugEnabled()) {
			logger.debug("delete(MemoVO) - start 인수 : "+ memoVO); //$NON-NLS-1$
		}

		SqlSession sqlSession = null;
		MemoDAO memoDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			memoDAO = MemoDAO.getInstance();
			//---------------------------------------------------------------
			// 여기가 바뀐다.
			if(memoVO!=null) {
				MemoVO dbVO = memoDAO.selectByIdx(sqlSession, memoVO.getIdx());
				if(dbVO!=null && dbVO.getPassword().equals(memoVO.getPassword())) {
					count = memoDAO.delete(sqlSession, memoVO.getIdx());
				}
			}
			//---------------------------------------------------------------
			sqlSession.commit();
		} catch (Exception e) {
			logger.error("delete(MemoVO) 에러 : " + e.getMessage()); //$NON-NLS-1$
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}

		if (logger.isDebugEnabled()) {
			logger.debug("delete(MemoVO) - end 리턴 : " + count); //$NON-NLS-1$
		}						
		return count;
	}
	
	
}
