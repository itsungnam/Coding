package kr.manamana.note;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@Resource(name = "uploadPath")
	private String uploadPath;

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);

		return "home";
	}

	@RequestMapping(value = "/form", method = RequestMethod.GET)
	public String form() {
		return "form";
	}

	@RequestMapping(value = "/result")
	public String result(HttpServletRequest request, Model model) {
		String subject = request.getParameter("subject");
		String result = request.getParameter("note");
		model.addAttribute("result", result);
		model.addAttribute("subject", subject);
		return "result";
	}

	@RequestMapping(value = "/form2", method = RequestMethod.GET)
	public String form2() {
		return "form2";
	}
	@RequestMapping(value = "/result2")
	public String result2(HttpServletRequest request, Model model) {
		String subject = request.getParameter("subject");
		String result = request.getParameter("note");
		model.addAttribute("result", result);
		model.addAttribute("subject", subject);
		return "result";
	}

	// Post 방식 파일 업로드
	@RequestMapping(value = "/profileImage", produces = "text/plain;charset=utf-8")
	@ResponseBody
	public String multiUploadFormPOST(MultipartHttpServletRequest request) throws Exception {
		logger.info("multiUploadFormPOST");
		// 서버의 실제 경로
		@SuppressWarnings("deprecation")
		String realPath = request.getRealPath(uploadPath);
		logger.info("서버경로 : " + realPath);
		// 파일받기
		List<MultipartFile> files = request.getFiles("file");
		logger.info("files : " + files);
		if (files == null || files.size() == 0) {
			return "redirect:/form2";
		}
		String savedName = "";
		for (MultipartFile file : files) {
			if (file != null && file.getSize() > 0) {
				savedName = uploadFile(request, realPath, file.getOriginalFilename(), file.getBytes());
			}
		}
		return savedName;
	}

	// 업로드된 파일을 저장하는 함수
	private String uploadFile(MultipartHttpServletRequest request, String realPath, String originalName, byte[] fileData) throws IOException {
		UUID uid = UUID.randomUUID();
		String savedName = uid.toString() + "_" + originalName;
		File target = new File(realPath, savedName);
		// org.springframework.util 패키지의 FileCopyUtils는 파일 데이터를 파일로 처리하거나, 복사하는 등의 기능이
		// 있다.
		FileCopyUtils.copy(fileData, target);
		String contextPath = request.getContextPath();
		return contextPath + "/upload/" + savedName; // 이미지가 저장된 URL을 리턴하면 된다.
	}
}
