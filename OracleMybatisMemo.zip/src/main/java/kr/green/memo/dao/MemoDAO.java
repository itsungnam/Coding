package kr.green.memo.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.green.memo.vo.MemoVO;

public class MemoDAO {
	private static MemoDAO instance = new MemoDAO();

	private MemoDAO() {
	}

	public static MemoDAO getInstance() {
		return instance;
	}
	//==================================================================================
	// <!-- 1. 개수 얻기 --> 	
	public int selectCount(SqlSession sqlSession) {
		return sqlSession.selectOne("memo.selectCount");
	}
	// <!-- 2. 1개 얻기 --> 	
	public MemoVO selectByIdx(SqlSession sqlSession, int idx) {
		return sqlSession.selectOne("memo.selectByIdx", idx);
	}
	
	public HashMap<String, Object> selectByIdxMap(SqlSession sqlSession, int idx) {
		return sqlSession.selectOne("memo.selectByIdxMap", idx);
	}
	
	// <!-- 3. 1페이지 얻기 --> 	
	public List<MemoVO> selectList(SqlSession sqlSession, HashMap<String, Integer> map) {
		return sqlSession.selectList("memo.selectList", map);
	}
	// 4. 저장
	public int insert(SqlSession sqlSession, MemoVO memoVO) {
		return sqlSession.insert("memo.insert", memoVO);
	}
	// 5. 수정
	public int update(SqlSession sqlSession, MemoVO memoVO) {
		return sqlSession.update("memo.update", memoVO);
	}
	// 6. 삭제
	public int delete(SqlSession sqlSession, int idx) {
		return sqlSession.delete("memo.delete", idx);
	}
}
